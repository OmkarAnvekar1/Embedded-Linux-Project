import serial
import json
import time

# Replace with the ESP32's USB port on Ubuntu (e.g., "/dev/ttyUSB0")
esp32_port = "/dev/ttyUSB0"
baud_rate = 115200

# Open the serial connection
ser = serial.Serial(esp32_port, baud_rate, timeout=1)

def parse_weather_data(data):
    try:
        # Parse the JSON response from the ESP32
        weather = json.loads(data)
        print("\nCurrent Weather Data:")
        print(f"Location: {weather['location']['name']}, {weather['location']['country']}")
        print(f"Temperature: {weather['current']['temp_c']}°C")
        print(f"Condition: {weather['current']['condition']['text']}")
        print(f"Humidity: {weather['current']['humidity']}%")
        print(f"Wind Speed: {weather['current']['wind_kph']} kph")
    except json.JSONDecodeError:
        print("Failed to parse JSON")

while True:
    # Read a line from the ESP32
    if ser.in_waiting > 0:
        data = ser.readline().decode('utf-8').strip()
        if data:
            parse_weather_data(data)
    
    # Wait for 3 seconds before checking again
    time.sleep(0.1)

